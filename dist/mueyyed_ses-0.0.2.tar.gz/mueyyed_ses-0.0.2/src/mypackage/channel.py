import webbrowser

url = 'https://www.youtube.com/watch?v=YVQ6D1CdmC4'
webbrowser.open(url)